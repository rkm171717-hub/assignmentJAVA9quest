package com.financial.budgetplanner.dto;

public class BudgetDTO {
    private Long userId;
    private String category;
    private Double amount;
    private String description;

    // Constructors
    public BudgetDTO() {}

    public BudgetDTO(Long userId, String category, Double amount, String description) {
        this.userId = userId;
        this.category = category;
        this.amount = amount;
        this.description = description;
    }

    // Getters and Setters
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
